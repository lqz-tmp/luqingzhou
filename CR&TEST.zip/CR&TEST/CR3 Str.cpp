#include <bits/stdc++.h>
using namespace std;

int main()
{
  freopen("in.txt","w",stdout);
  int i,n,m;
  string str;
  n=  ;
  m=  ;
  srand((unsigned)time(NULL));
  for(i=1;i<=n;i++)
  {
    str="";
    for(int j=1;j<=m;j++)
    {
      int temp=rand()%2;
	  if (temp==0)		
        str+=(char)(rand()%(26)+1+64);
      else
	    str+=(char)(rand()%(26)+1+96);
    }
    cout<<str<<endl;
  }	
  return 0;
}
