#include <bits/stdc++.h> 
using namespace std;

int main()
{
  freopen("in.txt","w",stdout);
  int low,hight,k;
  srand((unsigned)time(NULL));
  low=  ;
  hight=  ;  //low<=hight
  k=  ;
  for(int i=1;i<=k;i++)
    cout<<rand() %(hight-low+1)+low<<' '; 
  return 0;
}