#include <bits/stdc++.h>
using namespace std;
int main()
{
  int a,b;  
  freopen("sum.in","r",stdin);
  freopen("sum.out","w",stdout);
  cin>>a>>b;
  cout<<a+b<<endl;
  return 0;
}

  // for(i=0;scanf("%d",&a[i])!=EOF;i++);
  //scanf为c语言读写方式，直到读到文件末尾