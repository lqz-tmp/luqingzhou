#include <bits/stdc++.h>
#include <windows.h>
using namespace std;

int main()
{
  clock_t time;
  time=clock();


//���򲿷�

  cout<<clock()-time<<"����"<<endl;
  return 0;      
}
