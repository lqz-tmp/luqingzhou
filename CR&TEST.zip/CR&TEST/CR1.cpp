#include <bits/stdc++.h>
using namespace std;    

int main()
{
  freopen("in.txt","w",stdout);
  srand((unsigned)time(NULL));
  cout<<rand()%1000<<endl; 
  return 0;
}
