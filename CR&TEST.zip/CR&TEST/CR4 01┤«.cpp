#include <bits/stdc++.h>
using namespace std;

int main()
{
  freopen("in.txt","w",stdout);
  int len;
  len=  ;
  srand((unsigned)time(NULL));
  for(int i=1;i<=len;i++)
    cout<<rand() % (2)<<' ';
  return 0;
}
